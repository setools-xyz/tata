def print_tata():
    print("TATA")
